import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Program extends JFrame {
	
	
	private JPanel contentPane;
	private DbMethods dbm = new DbMethods();
	private EmpTM etm;
	
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Program frame = new Program();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		});
	}

	/**
	 * Create the frame.
	 */
	public Program() {
		dbm.Reg();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		JButton btnLista = new JButton("T\u00E1rsash\u00E1zak list\u00E1z\u00E1sa");
		btnLista.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.connect();
				etm= dbm.ReadData();
				dbm.DisConnect();
				EmpList el = new EmpList(Program.this, etm);
				el.setVisible(true);
				
			}
		});
		btnLista.setBounds(129, 21, 171, 23);
		contentPane.add(btnLista);
		
		JButton btnujhaz = new JButton("\u00DAj T\u00E1rsash\u00E1z");
		btnujhaz.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NewEmp ne = new NewEmp();
				ne.setVisible(true);
			}
		});
		btnujhaz.setBounds(129, 67, 171, 23);
		contentPane.add(btnujhaz);
		
		JButton btnTorles = new JButton("T\u00E1rsash\u00E1z T\u00F6rl\u00E9se");
		btnTorles.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					dbm.connect();
					etm= dbm.ReadData();
					dbm.DisConnect();
					EmpDel ed = new EmpDel(Program.this, etm);
					ed.setVisible(true);
			}
		});
		btnTorles.setBounds(129, 117, 171, 23);
		contentPane.add(btnTorles);
		
		JButton btnModosit = new JButton("T\u00E1rsash\u00E1z M\u00F3dos\u00EDt\u00E1sa");
		btnModosit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dbm.connect();
				etm= dbm.ReadData();
				dbm.DisConnect();
				EmpMod em = new EmpMod(Program.this, etm);
				em.setVisible(true);
			}
		});
		btnModosit.setBounds(129, 178, 171, 23);
		contentPane.add(btnModosit);
		
		Object emptmn[]= {"Jel", "Azonos�t�", "C�m", "Ter�let", "K�z�sk�lts�g","Utols� Befizet�s"};
		EmpTM etm = new EmpTM(emptmn,0);
	
		
}
	}

