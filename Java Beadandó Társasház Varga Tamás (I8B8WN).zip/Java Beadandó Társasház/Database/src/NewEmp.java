import java.awt.EventQueue;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class NewEmp extends JDialog {
	private JTextField id;
	private JTextField cim;
	private JTextField ter;
	private JTextField kozklt;
	private JTextField ubfiz;
	private DbMethods dbm = new DbMethods();
	

	
	public NewEmp() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		JLabel lblAzonosito = new JLabel("Azonos\u00EDt\u00F3:");
		lblAzonosito.setBounds(51, 21, 126, 25);
		getContentPane().add(lblAzonosito);
		
		JLabel lblcim = new JLabel("C\u00EDm:");
		lblcim.setBounds(51, 58, 126, 14);
		getContentPane().add(lblcim);
		
		JLabel lblTerulet = new JLabel("Ter\u00FClet:");
		lblTerulet.setBounds(51, 89, 126, 14);
		getContentPane().add(lblTerulet);
		
		JLabel lblkozklt = new JLabel("K\u00F6z\u00F6s k\u00F6lts\u00E9g:");
		lblkozklt.setBounds(51, 120, 126, 14);
		getContentPane().add(lblkozklt);
		
		JLabel lblbefizdat = new JLabel("Utols\u00F3 befizet\u00E9s D\u00E1tuma:");
		lblbefizdat.setBounds(51, 157, 142, 14);
		getContentPane().add(lblbefizdat);
		
		id = new JTextField();
		id.setBounds(228, 23, 172, 20);
		getContentPane().add(id);
		id.setColumns(10);
		
		cim = new JTextField();
		cim.setBounds(228, 55, 172, 20);
		getContentPane().add(cim);
		cim.setColumns(10);
		
		ter = new JTextField();
		ter.setColumns(10);
		ter.setBounds(228, 86, 172, 20);
		getContentPane().add(ter);
		
		kozklt = new JTextField();
		kozklt.setBounds(228, 117, 172, 20);
		getContentPane().add(kozklt);
		kozklt.setColumns(10);
		
		ubfiz = new JTextField();
		ubfiz.setColumns(10);
		ubfiz.setBounds(228, 154, 172, 20);
		getContentPane().add(ubfiz);
		
		JButton btnbeszur = new JButton("Besz\u00FAr\u00E1s");
		btnbeszur.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Checker c = new Checker();
				if (c.goodInt(id, "Azonos�t�"))
					if (c.filled(cim, "C�m"))
					if (c.filled(ter, "Ter�let"))
							if(c.goodInt(kozklt, "K�z�sk�lts�g"))
								if (c.goodDate(ubfiz, "Utols� Befizet�s")) {
						
				dbm.connect();
				dbm.InsertData(RTF(id), RTF(cim), RTF(ter), RTF(kozklt), RTF(ubfiz));
				dbm.DisConnect();
				}
			}
		});
		btnbeszur.setBounds(167, 212, 89, 23);
		getContentPane().add(btnbeszur);

	}
	public String RTF (JTextField jtf) {
		return jtf.getText();
	}
}
