import java.awt.BorderLayout;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;

import com.sun.jdi.Method;

import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public  class EmpDel extends JDialog {
	private final JPanel contentPanel = new JPanel();
	private JTable table;
	private EmpTM etm;
	private Checker c = new Checker();
	private DbMethods dbm = new DbMethods(); 
 
	
	public EmpDel(JFrame f, EmpTM betm) {
		super(f, "T�rsash�zak T�rl�se", true);
		etm=betm;
		
		setBounds(100, 100, 679, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5,5,5,5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
		
			JButton btnBezar = new JButton("Bez\u00E1r\u00E1s");
			btnBezar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					dispose ();
				}
			});
			btnBezar.setBounds(283, 233, 89, 23);
			contentPanel.add(btnBezar);
		}
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 643, 211);
		contentPanel.add(scrollPane);
		
		table = new JTable(etm);
		scrollPane.setViewportView(table);
		
		JButton btnTrls = new JButton("T\u00F6rl\u00E9s");
		btnTrls.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int db=0, Jel=0, x=0;
				for(x = 0; x<etm.getRowCount();x++)
					if ((Boolean)etm.getValueAt(x,0)) {db++; Jel=x;}
					if (db==0) c.SM("Nincs kijel�lve t�rlend� T�rsash�z!", 0);
					if (db>1) c.SM("T�bb T�rsash�z van kijel�lve! (Egyszerre csak egy t�r�lhet�)", 0); 
					if (db==1) {
						String id= etm.getValueAt(Jel, 1).toString();
						dbm.connect();
						dbm.DelData(id);
						dbm.DisConnect();
						etm.removeRow(Jel);
						c.SM("A T�rsash�z t�r�lve",1);
					}
			}
		});
		btnTrls.setBounds(20, 233, 116, 23);
		contentPanel.add(btnTrls);
		
		TableColumn tc= null;
		for (int i=0; i<6; i++) {
			tc=table.getColumnModel().getColumn(i);
			if (i==0 || i==1 || i==4) tc.setPreferredWidth(30);
			else {tc.setPreferredWidth(100);
		}
		table.setAutoCreateRowSorter(true);
		TableRowSorter<EmpTM> trs= (TableRowSorter<EmpTM>)table.getRowSorter();
		trs.setSortable(0, false);
		
		
	}
		
	
	
	}
}
