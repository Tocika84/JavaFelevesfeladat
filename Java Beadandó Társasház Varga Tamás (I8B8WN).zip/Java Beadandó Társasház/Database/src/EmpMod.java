import java.awt.BorderLayout;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumn;
import javax.swing.table.TableRowSorter;

import com.sun.jdi.Method;

import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JTextField;

public  class EmpMod extends JDialog {
	private final JPanel contentPanel = new JPanel();
	private JTable table;
	private EmpTM etm;
	private Checker c = new Checker();
	private DbMethods dbm = new DbMethods(); 
	private JTextField id;
	private JTextField cim;
	private JTextField ter;
	private JTextField kozklt;
	private JTextField ubfiz;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
 
	
	public EmpMod(JFrame f, EmpTM betm) {
		super(f, "T�rsash�zak M�dos�t�sa", true);
		etm=betm;
		
		setBounds(100, 100, 680, 359);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5,5,5,5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
		
			JButton btnBezar = new JButton("Bez\u00E1r\u00E1s");
			btnBezar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					dispose ();
				}
			});
			btnBezar.setBounds(283, 263, 89, 23);
			contentPanel.add(btnBezar);
		}
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 643, 175);
		contentPanel.add(scrollPane);
		
		table = new JTable(etm);
		scrollPane.setViewportView(table);
		
		JButton btnmodosit = new JButton("M\u00F3dos\u00EDt\u00E1s");
		btnmodosit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int db=0, Jel=0, x=0;
				for(x = 0; x<etm.getRowCount();x++)
					if ((Boolean)etm.getValueAt(x,0)) {db++; Jel=x;}
					if (db==0) c.SM("Nincs kijel�lve m�dos�tand� T�rsash�z!", 0);
					
					if (db>1) c.SM("T�bb T�rsash�z van kijel�lve! (Egyszerre csak egy m�dos�that�)", 0); 
					
					if (db==1) {
						if (modDataPc() >0) {
							boolean ok= true;
							if (c.filled(id)) ok= c.goodInt(id,"Azonos�t�");
							if (ok && c.filled(kozklt)) ok = c.goodInt(kozklt, "K�z�sk�lts�g");
							if(ok) {
								String mkod = etm.getValueAt(Jel, 1).toString();
								dbm.connect();
								if(c.filled(cim)) dbm.UpdateData(mkod, "c�m", c.RTF(cim));
								if(c.filled(ter)) dbm.UpdateData(mkod, "ter�let", c.RTF(ter));
								if(c.filled(kozklt)) dbm.UpdateData(mkod, "k�zk�lt", c.RTF(kozklt));
								if(c.filled(ubfiz)) dbm.UpdateData(mkod, "utbefiz", c.RTF(ubfiz));
								if(c.filled(id)) dbm.UpdateData(mkod, "id", c.RTF(id));
								dbm.DisConnect();
								
								if (c.filled(id)) etm.setValueAt(c.strinToInt(c.RTF(id)), Jel, 1);
								if (c.filled(cim)) etm.setValueAt(c.RTF(cim), Jel, 2);
								if (c.filled(ter)) etm.setValueAt(c.RTF(ter), Jel, 3);
								if (c.filled(kozklt)) etm.setValueAt(c.strinToInt(c.RTF(kozklt)), Jel, 4);
								if (c.filled(ubfiz)) etm.setValueAt(c.RTF(ubfiz), Jel, 5);
								c.SM("A T�rsash�z M�dos�tva",1);
								
								
							
							}
							else {
								c.SM("Nincs kit�ltve egy m�dos�t� mezez� sem!",0);
							}
						}
					}
					
			}
		});
		btnmodosit.setBounds(23, 263, 116, 23);
		contentPanel.add(btnmodosit);
		
		id = new JTextField();
		id.setBounds(81, 197, 47, 20);
		contentPanel.add(id);
		id.setColumns(10);
		
		cim = new JTextField();
		cim.setBounds(138, 197, 135, 20);
		contentPanel.add(cim);
		cim.setColumns(10);
		
		ter = new JTextField();
		ter.setBounds(283, 197, 148, 20);
		contentPanel.add(ter);
		ter.setColumns(10);
		
		kozklt = new JTextField();
		kozklt.setBounds(441, 197, 65, 20);
		contentPanel.add(kozklt);
		kozklt.setColumns(10);
		
		ubfiz = new JTextField();
		ubfiz.setBounds(531, 197, 98, 20);
		contentPanel.add(ubfiz);
		ubfiz.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Azonos\u00EDt\u00F3");
		lblNewLabel.setBounds(80, 228, 59, 14);
		contentPanel.add(lblNewLabel);
		
		JLabel lblCm = new JLabel("C\u00EDm");
		lblCm.setBounds(196, 228, 46, 14);
		contentPanel.add(lblCm);
		
		lblNewLabel_1 = new JLabel("Ter\u00FClet");
		lblNewLabel_1.setBounds(335, 228, 46, 14);
		contentPanel.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("K\u00F6z\u00F6sk\u00F6lts\u00E9g");
		lblNewLabel_2.setBounds(441, 228, 86, 14);
		contentPanel.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("Utols\u00F3 Befizet\u00E9s");
		lblNewLabel_3.setBounds(541, 228, 99, 14);
		contentPanel.add(lblNewLabel_3);
		
		TableColumn tc= null;
		for (int i=0; i<6; i++) {
			tc=table.getColumnModel().getColumn(i);
			if (i==0 || i==1 || i==4) tc.setPreferredWidth(30);
			else {tc.setPreferredWidth(100);
		}
		table.setAutoCreateRowSorter(true);
		TableRowSorter<EmpTM> trs= (TableRowSorter<EmpTM>)table.getRowSorter();
		trs.setSortable(0, false);
		
		
	}
		
	
	
	}
	public int modDataPc() {
		int pc=0;
		if (c.filled(id)) pc++;
		if (c.filled(cim)) pc++;
		if (c.filled(ter)) pc++;
		if (c.filled(kozklt)) pc++;
		if (c.filled(ubfiz)) pc++;
		return pc;
	}
	 
	
}
