import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class DbMethods {
	private Statement s = null;
	private Connection conn= null;
	private ResultSet rs = null;
	
	public void Reg() {
		try {
			Class.forName("org.sqlite.JDBC");
		//	SM("Sikeres driver regisztr�ci�" ,1);
		} catch (ClassNotFoundException e ) {
			SM("Hib�s driver regisztr�ci�!"+e.getMessage(),0 );
		}
	}
	public void SM(String msg, int tipus) {
		JOptionPane.showMessageDialog(null, msg, "Program �zenet", tipus);
	}
	
	public void connect() {
		try {
			String url= "jdbc:sqlite:C:/JDBC/T�rsash�z";
			conn = DriverManager.getConnection(url);
		//	SM("Connection OK",1);
		}	catch (SQLException e) {
			SM("JDBC Connect: "+e.getMessage(),0);
			
		}
		
	}
	
	public void DisConnect() {
		try {
			conn.close();
		//	SM("DisConnection OK!", 1);
		}	catch (SQLException e) {SM(e.getMessage(),0);}
		
	}
	
	public EmpTM ReadData() {
		Object emptmn[]= {"Jel", "Azonos�t�", "C�m", "Ter�let", "K�z�sk�lts�g","Utols� Befizet�s"};
		EmpTM etm = new EmpTM(emptmn,0);
		String cim= "", ter="", ubfiz="", x="\t";
		int id=0, kozklt=0;
		String sqlp= "select id, c�m, ter�let, k�zk�lt, utbefiz from T�rsash�z";
		try {
			s = conn.createStatement();
			rs = s.executeQuery(sqlp);
			while (rs.next()) {
				id= rs.getInt("id");
				cim= rs.getString("c�m");
				ter= rs.getString("ter�let");
				kozklt= rs.getInt("k�zk�lt");
				ubfiz= rs.getString("utbefiz");
				etm.addRow(new Object[] {false, id, cim, ter, kozklt, ubfiz});
		
			}
			rs.close();
		}catch (SQLException e) {SM(e.getMessage(),0);}
		return etm;
	}
	
	public void InsertData(String id, String cim, String ter, String kozklt, String ubfiz ) {
		
		String sqlp ="insert into T�rsash�z values("+id+",\""+cim +"\", \""+ter+"\", "+kozklt+",\""+ubfiz+"\")";
		try {
			s= conn.createStatement();
			s.execute(sqlp);
			SM("�j T�rsash�z sikeresen L�trehozva!",1);
		}	catch(SQLException e) {
			SM("JDBC insert: "+e.getMessage(),0 );
		
		}
	}
	
	public void DelData(String id) {
		String sqlp = "delete from T�rsash�z where id =" +id;
		try {
			s = conn.createStatement();
			s.execute(sqlp);}
		catch (SQLException e) {
			SM("JDBC Delete: "+e.getMessage(),0);
			
		}
	}
	
	public void UpdateData(String id, String mnev, String madat) {
		String sqlp = "update T�rsash�z set "+mnev+"='"+madat+"' where id="+id;
		try {
			s = conn.createStatement();
			s.execute(sqlp);}
		catch (SQLException e) {
			SM("JDBC Update: "+e.getMessage(),0);
			
		}
		
	}
	
}


